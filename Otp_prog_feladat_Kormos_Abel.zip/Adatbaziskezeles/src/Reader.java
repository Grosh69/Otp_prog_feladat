import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Reader {
    public static void readCustomer(String customersFile, ArrayList<Customer> customers) throws FileNotFoundException {
        try
        {
            File file = new File(customersFile);
            if ( file.exists() && file.length() != 0){
                Scanner reader = new Scanner(file);
                String firstLine = reader.nextLine();
                while(reader.hasNextLine()){
                    String line = reader.nextLine();
                    if (line != firstLine ){
                        String[] separetedParts = line.split(",");
                        Customer customer = new Customer(Integer.parseInt(separetedParts[0]),separetedParts[1],separetedParts[2]);
                        customers.add(customer);
                    }
                }
            }


        } catch (Exception e){
            throw new FileNotFoundException();
        }
    }

    public static void readOrder(String ordersFile, ArrayList<Order> orders) throws FileNotFoundException {
        try
        {
            File file = new File(ordersFile);
            if ( file.exists() && file.length() != 0){
                Scanner reader = new Scanner(file);
                String firstLine = reader.nextLine();
                while(reader.hasNextLine()){
                    String line = reader.nextLine();
                    if (line != firstLine ){
                        String[] separetedParts = line.split(",");
                        String dateString = separetedParts[2];
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                        LocalDate date = LocalDate.parse(dateString, formatter);
                        Order order = new Order(Integer.parseInt(separetedParts[0]),Integer.parseInt(separetedParts[1]), date,Double.parseDouble(separetedParts[3]),separetedParts[4]);
                        orders.add(order);
                    }
                }

            }


        } catch (Exception e){
            throw new FileNotFoundException();
        }
    }
}
