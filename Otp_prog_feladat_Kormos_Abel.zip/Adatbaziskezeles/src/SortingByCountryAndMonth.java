import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class SortingByCountryAndMonth {


    public static Map<String, Double> sortedByCountryAndMonth(ArrayList<Customer> customers, ArrayList<Order> orders) {

        Map<Integer, String> customerMap = new HashMap<>();
        for (Customer c : customers) {
            customerMap.put(c.getCustomer_id(), c.getCountry());
        }

        Map<String, Double> stats = new TreeMap<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
        for (Order order : orders) {
            String country = customerMap.get(order.getCustomer_id());
            String monthKey = order.getOrder_date().format(formatter);

            String key = country + ", " + monthKey;

            stats.put(key, stats.getOrDefault(key, 0.0) + order.getTotal_amount());
        }

        return stats;
    }


    public static void writeToFileByCountryAndMonth(ArrayList<Customer> customers, ArrayList<Order> orders) throws IOException {
        Map<String, Double> map = sortedByCountryAndMonth(customers, orders);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("SortedByCountrysAndMonths.csv"))) {

            writer.write("Country, Month, Total Amount\n");

            for (Map.Entry<String, Double> entry : map.entrySet()) {
                writer.write(entry.getKey() + ", " + String.format("%.2f", entry.getValue()) + "\n");
            }

        }
    }
}



