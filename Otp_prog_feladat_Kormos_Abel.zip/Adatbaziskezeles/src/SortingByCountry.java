import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SortingByCountry {

    public static Map<String, Double> sortedByCountry(ArrayList<Customer> customers, ArrayList<Order> orders) {

        Map<Integer, String> customerMap = new HashMap<>();
        for (Customer c : customers) {
            customerMap.put(c.getCustomer_id(), c.getCountry());
        }

        Map<String, Double> countryTotal = new HashMap<>();
        for (Order o : orders) {
            String country = customerMap.get(o.getCustomer_id());
            countryTotal.put(country, countryTotal.getOrDefault(country, 0.0) + o.getTotal_amount());
        }


        return countryTotal;
    }

    public static void writeToFileByCountry(ArrayList<Customer> customers, ArrayList<Order> orders) throws IOException {
        Map <String, Double> map = sortedByCountry(customers,orders);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("SortedByCountrys.csv"))) {

            writer.write("Country,Total Amount\n");

            for (Map.Entry<String, Double> entry : map.entrySet()) {
                writer.write(entry.getKey() + ": " + String.format("%.2f", entry.getValue()) + "\n");
            }

        }
    }
}
