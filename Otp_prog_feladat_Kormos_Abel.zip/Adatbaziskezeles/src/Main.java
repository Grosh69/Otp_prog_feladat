import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        String customersFile = "src/Data/customers.csv";
        ArrayList<Customer> customers = new ArrayList<>();

        String ordersFile = "src/Data/orders.csv";
        ArrayList<Order> orders = new ArrayList<>();

        Reader.readCustomer(customersFile,customers);
        Reader.readOrder(ordersFile,orders);

        SortingByCountry.writeToFileByCountry(customers,orders);
        SortingByMonths.writeToFileByMonths(customers,orders);
        SortingByCountryAndMonth.writeToFileByCountryAndMonth(customers,orders);





    }

}