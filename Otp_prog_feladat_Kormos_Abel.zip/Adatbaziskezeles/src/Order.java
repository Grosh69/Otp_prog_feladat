import java.time.LocalDate;


public class Order {

    private int order_id;
    private int customer_id;
    private LocalDate order_date;
    private Double total_amount;
    private String currency;

    public Order(int order_id, int customer_id,  LocalDate order_date,Double total_amount, String currency) {
        this.order_id = order_id;
        this.customer_id = customer_id;
        this.total_amount = total_amount;
        this.order_date = order_date;
        this.currency = currency;
    }

    public int getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(int customer_id) {
        this.customer_id = customer_id;
    }

    public LocalDate getOrder_date() {
        return order_date;
    }

    public void setOrder_date(LocalDate order_date) {
        this.order_date = order_date;
    }

    public Double getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(Double total_amount) {
        this.total_amount = total_amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

}
