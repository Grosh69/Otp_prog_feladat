import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class SortingByMonths {

    public static Map<String, Double> sortedByMonths(ArrayList<Customer> customers, ArrayList<Order> orders) {
        Map<String, Double> monthTotal = new HashMap<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
        for (Order o : orders) {
            int m = o.getOrder_date().getMonthValue();
            String month = o.getOrder_date().format(formatter);
            monthTotal.put(month, monthTotal.getOrDefault(month, 0.0) + o.getTotal_amount());
        }
        return monthTotal;
    }

    public static void writeToFileByMonths(ArrayList<Customer> customers, ArrayList<Order> orders) throws IOException {
        Map <String, Double> map = sortedByMonths(customers,orders);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("SortedByMonth.csv"))) {

            writer.write("Month,Total Amount\n");

            for (Map.Entry<String, Double> entry : map.entrySet()) {

                writer.write(entry.getKey() + ": " + String.format("%.2f", entry.getValue()) + "\n");
            }

        }
    }
}
